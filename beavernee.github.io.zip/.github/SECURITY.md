# Security Policy

## Supported Versions

| Version | Supported          |
|---------| ------------------ |
| 5.x     | :white_check_mark: |
| < 5.0.0 | :x:                |

## Reporting a Vulnerability

If you find a vulnerability, please report it to `cotes.chung@gmail.com`. We will try our best to respond within a week. Thank you for your time!
